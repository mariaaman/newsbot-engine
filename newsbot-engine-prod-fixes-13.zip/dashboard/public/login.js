const $ = (id) => document.getElementById(id);
fetch("/api/session").then((r) => r.json()).then((s) => { if (s.totp) $("cw").hidden = false; }).catch(() => {});
$("f").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("go").disabled = true; $("err").textContent = "";
  try {
    const r = await fetch("/api/login", { method: "POST", headers: { "Content-Type": "application/json", "X-Requested-With": "newsbot" }, body: JSON.stringify({ password: $("p").value, code: $("c").value }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || "failed");
    location.href = "/";
  } catch (x) { $("err").textContent = x.message; $("go").disabled = false; }
});
