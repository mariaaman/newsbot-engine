import { parseHead, ago, safeHref, runIcon, pct } from "./lib.js";

const view = document.getElementById("view");
const NAV = [["#/", "🏠", "হোম"], ["#/drafts", "📝", "খসড়া"], ["#/articles", "📰", "আর্টিকেল"], ["#/settings", "⚙️", "সেটিংস"], ["#/keys", "🔑", "কী"], ["#/runs", "▶️", "রান"], ["#/more", "☰", "আরও"]];

function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === "class") el.className = v;
    else if (k === "on") for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
    else if (k === "href") el.setAttribute("href", safeHref(v));
    else if (k in el && k !== "list") el[k] = v;
    else el.setAttribute(k, v);
  }
  for (const kid of kids.flat(3)) { if (kid == null || kid === false) continue; el.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
  return el;
}

async function api(path, method = "GET", body) {
  const r = await fetch(path, { method, headers: { "X-Requested-With": "newsbot", ...(body ? { "Content-Type": "application/json" } : {}) }, body: body ? JSON.stringify(body) : undefined });
  if (r.status === 401) { location.reload(); throw new Error("login"); }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || `error ${r.status}`); e.data = j; throw e; }
  return j;
}

let toastTimer;
function toast(msg, bad = false) {
  document.querySelectorAll(".toast").forEach((t) => t.remove());
  const t = h("div", { class: "toast" + (bad ? " bad" : ""), role: "status" }, msg);
  document.body.append(t);
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.remove(), bad ? 7000 : 3500);
}
async function run(btn, fn) {
  if (btn) btn.disabled = true;
  try { return await fn(); } catch (e) { toast(e.message, true); } finally { if (btn) btn.disabled = false; }
}
const MSG = { approved: "✅ অনুমোদিত। ১–৩ মিনিটে প্রকাশ হবে।", approvedNoDeploy: "✅ অনুমোদিত, কিন্তু ডিপ্লয় চালু হয়নি। পরের hourly রানে প্রকাশ হবে।", rejected: "🗑 বাতিল করা হয়েছে।", saved: "💾 সংরক্ষিত।",
  gone: "ℹ️ এটি আগেই নিষ্পন্ন হয়েছে।", gate: "⛔ মান-যাচাইয়ে ব্যর্থ: নিচের টিক দিয়ে নিজে যাচাইয়ের নিশ্চয়তা দিন।", stale: "⚠️ খসড়াটি বদলে গেছে, রিফ্রেশ করুন।",
  published: "✅ সংরক্ষিত, সাইট ডিপ্লয় হচ্ছে।", publishedNoDeploy: "✅ সংরক্ষিত, কিন্তু ডিপ্লয় চালু হয়নি।", nochange: "কোনো পরিবর্তন নেই।" };

// Element.append(null) writes the word "null" on the page, so every append goes through these two helpers.
const kids = (k) => k.flat(3).filter((x) => x != null && x !== false);
const add = (el, ...k) => el.append(...kids(k));
const fill = (el, ...k) => el.replaceChildren(...kids(k));
const clear = () => view.replaceChildren();
const section = (title, ...kids) => h("section", null, h("h2", null, title), ...kids);
const chip = (t, cls = "") => h("span", { class: "chip " + cls }, t);
const link = (text, href) => h("a", { href, target: "_blank", rel: "noopener noreferrer", class: "btn sm" }, text);
const fmtNum = (n) => (typeof n === "number" ? n.toLocaleString("en-US") : "—");

// ---------- Home ----------
async function home() {
  const o = await api("/api/overview");
  clear();
  document.getElementById("title").textContent = o.site.name || "NewsBot Control";
  const siteOk = o.site.check && o.site.check.status >= 200 && o.site.check.status < 400;
  const last = o.lastHourly;
  const total = (c) => (c.bn || 0) + (c.en || 0);
  add(view, 
    h("h1", null, "সারসংক্ষেপ"),
    h("div", { class: "card" + (siteOk ? "" : " bad") }, h("div", { class: "row sb" }, h("b", null, o.site.name || "সাইট"), siteOk ? chip(`চালু · ${o.site.check.ms} ms`, "ok") : chip("সাড়া নেই", "bad")),
      o.site.url ? h("div", null, h("a", { href: o.site.url, target: "_blank", rel: "noopener noreferrer" }, o.site.url)) : null,
      h("div", { class: "mut" }, "সর্বশেষ ডিপ্লয়: ", ago(o.site.deployed))),
    h("div", { class: "card" }, h("div", { class: "row sb" }, h("b", null, "প্রকাশের মোড"), chip(o.mode, o.mode === "auto" ? "bad" : "ok")),
      h("div", { class: "mut" }, o.mode === "review" ? "আপনি দেখে অনুমোদন দেন। সংবেদনশীল খসড়া সবসময় আপনার কাছে আসে।" : "নিজে প্রকাশ হয়। সংবেদনশীল খসড়া তবুও আটকে থাকে।"),
      h("div", { class: "row", style: "margin-top:.5rem" }, h("button", { class: "sm", type: "button", on: { click: (e) => run(e.target, async () => {
        const to = o.mode === "review" ? "auto" : "review";
        if (!confirm(`মোড বদলে "${to}" করবেন?`)) return;
        await api("/api/settings", "POST", { changes: [{ file: "config/newsbot.yaml", kind: "field", path: ["publish", "mode"], value: to }] });
        toast("মোড বদলানো হয়েছে"); route();
      }) } }, o.mode === "review" ? "auto-তে নিন" : "review-তে ফেরান"))),
    h("div", { class: "card" }, h("b", null, "আর্টিকেল"),
      h("div", { class: "row" }, chip(`প্রকাশিত ${total(o.counts.published)} (বাংলা ${o.counts.published.bn}, ইংরেজি ${o.counts.published.en})`), chip(`খসড়া ${total(o.counts.pending)}`, total(o.counts.pending) ? "bad" : ""))),
    h("div", { class: "card" + (last && last.conclusion === "failure" ? " bad" : "") }, h("div", { class: "row sb" }, h("b", null, "সর্বশেষ hourly রান"), last ? h("span", null, runIcon(last), " ", ago(last.created)) : "—"),
      last ? h("div", { class: "mut" }, `${last.event} · ${last.status}${last.conclusion ? " · " + last.conclusion : ""}`, " ", h("a", { href: last.url, target: "_blank", rel: "noopener noreferrer" }, "লগ")) : null,
      h("div", { class: "row", style: "margin-top:.5rem" },
        h("button", { class: "pri sm", type: "button", on: { click: (e) => run(e.target, async () => { await api("/api/dispatch", "POST", { workflow: "hourly" }); toast("hourly চালু করা হয়েছে"); }) } }, "এখনই চালান"),
        h("button", { class: "sm", type: "button", on: { click: (e) => run(e.target, async () => { await api("/api/dispatch", "POST", { workflow: "deploy" }); toast("ডিপ্লয় চালু করা হয়েছে"); }) } }, "সাইট ডিপ্লয়"))),
    section("মডেল ব্যবহার (আজ " + (o.usage.day || "—") + ")", usageTable(o.usage.counters), h("p", { class: "mut" }, `বিরতিতে থাকা স্টোরি: ${o.cooldowns}`)),
  );
  if (o.secrets) {
    const want = ["GROQ_API_KEY", "GEMINI_API_KEY", "TELEGRAM_BOT_TOKEN", "TELEGRAM_CHAT_ID", "CLOUDFLARE_API_TOKEN", "CLOUDFLARE_ACCOUNT_ID", "BRAIN_REPO_TOKEN"];
    const miss = want.filter((n) => !o.secrets.includes(n));
    if (miss.length) add(view, h("div", { class: "card warn" }, h("b", null, "অনুপস্থিত সিক্রেট"), h("div", null, miss.map((n) => chip(n, "bad")))));
  }
  if (o.ads) add(view, h("p", { class: "mut" }, "বিজ্ঞাপন চালু আছে।"));
}
function usageTable(counters) {
  const rows = Object.entries(counters || {});
  if (!rows.length) return h("p", { class: "mut" }, "আজ এখনো কোনো মডেল-কল হয়নি।");
  return h("div", { class: "card" }, h("table", null, h("tr", null, h("th", null, "মডেল"), h("th", null, "রিকোয়েস্ট"), h("th", null, "টোকেন")), rows.map(([k, v]) => h("tr", null, h("td", null, k), h("td", null, fmtNum(v.requests)), h("td", null, fmtNum(v.tokens))))));
}

// ---------- Drafts and articles ----------
const listState = { lang: "bn", q: "", offset: 0 };
async function listView(kind) {
  const isDraft = kind === "drafts";
  const d = await api(`/api/${isDraft ? "drafts" : "articles"}?lang=${listState.lang}&offset=${listState.offset}&q=${encodeURIComponent(listState.q)}`);
  clear();
  const search = h("input", { type: "search", placeholder: "নাম দিয়ে খুঁজুন", value: listState.q, on: { keydown: (e) => { if (e.key === "Enter") { listState.q = e.target.value.trim(); listState.offset = 0; route(); } } } });
  add(view, h("h1", null, isDraft ? "খসড়া" : "প্রকাশিত আর্টিকেল"),
    h("div", { class: "row" }, ["bn", "en"].map((l) => h("button", { class: "sm" + (listState.lang === l ? " pri" : ""), type: "button", on: { click: () => { listState.lang = l; listState.offset = 0; route(); } } }, l === "bn" ? "বাংলা" : "English")), h("div", { class: "grow" }, search)),
    h("p", { class: "mut" }, `মোট ${d.total}${d.matched !== d.total ? ` · মিলেছে ${d.matched}` : ""}`));
  if (!d.items.length) add(view, h("p", { class: "mut" }, isDraft ? "কোনো খসড়া নেই। 🎉" : "কিছু পাওয়া যায়নি।"));
  for (const it of d.items) {
    const p = parseHead(it.head);
    add(view, h("div", { class: "card" }, h("a", { href: `#/${isDraft ? "draft" : "article"}/${listState.lang}/${encodeURIComponent(it.slug)}` }, h("b", null, p.title || it.slug)),
      p.summary ? h("div", { class: "mut" }, p.summary.slice(0, 160)) : null,
      h("div", null, p.reasons.map((r) => chip(r, r.startsWith("sensitive:") ? "" : "bad")), p.hidden ? chip("সাইট থেকে লুকানো", "bad") : null, p.date ? h("span", { class: "mut" }, " " + p.date.slice(0, 16)) : null)));
  }
  if (d.matched > d.offset + d.items.length || d.offset > 0) add(view, h("div", { class: "row" },
    h("button", { type: "button", disabled: d.offset === 0, on: { click: () => { listState.offset = Math.max(0, d.offset - 15); route(); } } }, "← আগের"),
    h("button", { type: "button", disabled: d.matched <= d.offset + d.items.length, on: { click: () => { listState.offset = d.offset + 15; route(); } } }, "পরের →")));
}

async function editor(kind, lang, slug) {
  const isDraft = kind === "draft";
  const a = await api(`/api/${kind}?lang=${lang}&slug=${encodeURIComponent(slug)}`);
  clear();
  const gate = /(failures|unsupported):\s*\n\s*- /.test(a.pending || "");
  const t = h("input", { type: "text", value: a.title || "" }), s = h("textarea", { class: "sm", value: a.summary || "" }), b = h("textarea", { value: a.body });
  const ack = h("input", { type: "checkbox" });
  const edits = () => ({ title: t.value, summary: s.value, body: b.value });
  const send = (action, btn) => run(btn, async () => {
    if (action === "reject" && !confirm("খসড়াটি মুছে ফেলবেন?")) return;
    const res = await api(`/api/${kind}`, "POST", { lang, slug, action, edits: edits(), version: a.version, ack: ack.checked });
    toast(MSG[res.key] || res.key, !["approved", "saved", "rejected", "published", "publishedNoDeploy", "approvedNoDeploy", "nochange"].includes(res.key));
    if (["approved", "approvedNoDeploy", "rejected", "gone"].includes(res.key)) location.hash = "#/drafts"; else if (res.key === "saved" || res.key === "published" || res.key === "nochange") route();
  });
  add(view, h("div", { class: "row" }, h("a", { class: "btn sm", href: isDraft ? "#/drafts" : "#/articles" }, "← ফিরুন"), chip(lang), a.hidden ? chip("সাইট থেকে লুকানো", "bad") : null),
    h("h1", null, a.title || slug),
    a.pending ? h("div", { class: "card" + (gate ? " bad" : "") }, h("b", null, "আটকে আছে কারণ"), h("pre", null, a.pending)) : null);
  const pv = h("div", { class: "preview" }); pv.innerHTML = a.html;                        // the server escapes everything; links are http(s) only
  add(view, pv, h("details", null, h("summary", null, "ফ্যাক্ট-শিট ও সূত্র (দেখার জন্য)"), h("pre", null, a.front)),
    h("h2", null, "সম্পাদনা"), h("label", null, "শিরোনাম"), t, h("label", null, "সারাংশ"), s, h("label", null, "লেখা (Markdown)"), b,
    gate && isDraft ? h("label", { class: "check" }, ack, "মান-যাচাইয়ে ব্যর্থ ছিল, আমি নিজে নাম, সংখ্যা ও উদ্ধৃতি যাচাই করেছি") : null);
  const bar = h("div", { class: "bar" });
  if (isDraft) add(bar, h("button", { class: "go", type: "button", on: { click: (e) => send("approve", e.target) } }, "✅ অনুমোদন ও প্রকাশ"), h("button", { type: "button", on: { click: (e) => send("save", e.target) } }, "💾 সংরক্ষণ"), h("button", { class: "danger", type: "button", on: { click: (e) => send("reject", e.target) } }, "🗑 বাতিল"));
  else add(bar, h("button", { class: "pri", type: "button", on: { click: (e) => send("save", e.target) } }, "💾 সংরক্ষণ ও ডিপ্লয়"), h("button", { type: "button", on: { click: (e) => send(a.hidden ? "show" : "hide", e.target) } }, a.hidden ? "👁 আবার দেখান" : "🙈 সাইট থেকে লুকান"));
  add(view, bar);
}

// ---------- Settings ----------
async function settingsView() {
  const d = await api("/api/settings");
  clear();
  const changes = new Map();
  const bar = h("div", { class: "bar", hidden: true }), count = h("b", null, "");
  const refreshBar = () => { bar.hidden = changes.size === 0; count.textContent = `${changes.size}টি পরিবর্তন`; };
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const control = (f) => {
    const id = f.file + JSON.stringify(f.path), orig = f.present ? f.value : null;
    const mark = (wrap, v) => { if (same(v, orig) || (orig === null && (v === "" || v === null))) changes.delete(id); else changes.set(id, { file: f.file, kind: "field", path: f.path, value: v }); wrap.classList.toggle("changed", changes.has(id)); refreshBar(); };
    const wrap = h("div", { class: "field" });
    let input;
    if (f.type === "bool") { input = h("input", { type: "checkbox", checked: orig === true, on: { change: () => mark(wrap, input.checked) } }); add(wrap, h("label", { class: "check" }, input, f.label)); }
    else {
      add(wrap, h("label", null, f.label));
      if (f.type === "enum") input = h("select", { on: { change: () => mark(wrap, input.value) } }, f.options.map((o) => h("option", { value: o, selected: o === orig }, o)));
      else if (f.type === "int" || f.type === "float") input = h("input", { type: "number", step: f.type === "int" ? "1" : "any", value: orig ?? "", placeholder: orig === null ? "ফাইলে নেই, ডিফল্ট" : "", on: { input: () => mark(wrap, input.value === "" ? null : Number(input.value)) } });
      else if (f.type === "list") input = h("input", { type: "text", value: (orig || []).join(", "), on: { input: () => mark(wrap, input.value.split(",").map((x) => x.trim()).filter(Boolean)) } });
      else input = h(f.multiline ? "textarea" : "input", { ...(f.multiline ? { class: "sm" } : { type: "text" }), value: orig ?? "", on: { input: () => mark(wrap, input.value) } });
      add(wrap, input);
    }
    const hint = [f.help, f.min !== undefined ? `সর্বনিম্ন ${f.min}` : "", f.max !== undefined ? `সর্বোচ্চ ${f.max}` : "", f.present ? "" : "ফাইলে নেই; সংরক্ষণ করলে যোগ হবে"].filter(Boolean).join(" · ");
    if (hint) add(wrap, h("div", { class: "help" }, hint));
    return wrap;
  };
  add(view, h("h1", null, "সেটিংস"), h("p", { class: "mut" }, "প্রতিটি সংরক্ষণ brain রিপোতে একটা commit হয়, পরে CI স্বয়ংক্রিয় যাচাই করে। ভুল হলে নিচের ‘ফাইল’ অংশ থেকে আগের সংস্করণ ফিরিয়ে আনা যায়।"));
  for (const [gid, gname] of d.groups) {
    const fs = d.fields.filter((f) => f.group === gid);
    if (!fs.length) continue;
    add(view, h("details", { open: gid === "publish" || gid === "limits" }, h("summary", null, gname), h("div", { class: "card" }, fs.map(control))));
  }
  add(view, llmSection(d), rawSection(), bar);
  add(bar, count, h("span", { class: "row" }, h("button", { class: "sm", type: "button", on: { click: () => route() } }, "বাতিল"), h("button", { class: "pri sm", type: "button", on: { click: (e) => run(e.target, async () => {
    const res = await api("/api/settings", "POST", { changes: [...changes.values()], versions: Object.fromEntries(Object.entries(d.files).map(([k, v]) => [k, v && v.sha])) });
    toast(res.results.some((r) => r.changed) ? "✅ সংরক্ষিত। CI যাচাই চলছে (রান ট্যাবে দেখুন)" : "কোনো পরিবর্তন নেই"); route();
  }) } }, "সংরক্ষণ")));
}

function llmSection(d) {
  const apply = (btn, change, msg = "সংরক্ষিত") => run(btn, async () => { await api("/api/settings", "POST", { changes: [{ file: "config/llm.yaml", ...change }] }); toast(msg); route(); });
  const box = h("div", { class: "card" });
  add(box, h("b", null, "মডেল চেইন"), h("p", { class: "mut" }, "ক্রমানুযায়ী চেষ্টা হয়। মডেল আইডি ঘন ঘন বদলায়, তাই এখানে বদলান।"));
  for (const tier of d.tiers) {
    add(box, h("h3", null, tier));
    (d.chains[tier] || []).forEach((e, i) => {
      const prov = h("select", null, d.providers.map((p) => h("option", { value: p, selected: p === e.provider }, p)));
      const model = h("input", { type: "text", value: e.model || "" });
      add(box, h("div", { class: "row field" }, prov, h("div", { class: "grow" }, model),
        h("button", { class: "sm pri", type: "button", on: { click: (ev) => apply(ev.target, { kind: "chain", op: "set", tier, index: i, provider: prov.value, model: model.value.trim() }) } }, "সংরক্ষণ"),
        h("button", { class: "sm", type: "button", title: "এর পরে নতুন এন্ট্রি", on: { click: (ev) => apply(ev.target, { kind: "chain", op: "insert", tier, index: i + 1, provider: prov.value, model: model.value.trim() }, "কপি যোগ হয়েছে, এবার মডেল বদলান") } }, "＋"),
        h("button", { class: "sm danger", type: "button", on: { click: (ev) => { if (confirm("এন্ট্রিটি সরাবেন?")) apply(ev.target, { kind: "chain", op: "remove", tier, index: i }); } } }, "✕")));
    });
  }
  add(box, h("h3", null, "কাজ → স্তর"));
  for (const t of d.taskNames) {
    const sel = h("select", { on: { change: (ev) => apply(ev.target, { kind: "task", task: t, tier: sel.value }) } }, d.tiers.map((x) => h("option", { value: x, selected: x === d.tasks[t] }, x)));
    add(box, h("div", { class: "row field" }, h("div", { class: "grow" }, t), h("div", { class: "grow" }, sel)));
  }
  add(box, h("h3", null, "এমবেডিং"));
  const ep = h("select", null, d.providers.map((p) => h("option", { value: p, selected: p === d.embedding.provider }, p))), em = h("input", { type: "text", value: d.embedding.model || "" });
  add(box, h("div", { class: "row field" }, ep, h("div", { class: "grow" }, em), h("button", { class: "sm pri", type: "button", on: { click: (ev) => apply(ev.target, { kind: "embedding", provider: ep.value, model: em.value.trim() }) } }, "সংরক্ষণ")));
  for (const [map, title] of [["tokens_per_day", "দৈনিক টোকেন-সীমা"], ["requests_per_day", "দৈনিক রিকোয়েস্ট-সীমা"]]) {
    add(box, h("h3", null, title), h("p", { class: "mut" }, "কী: provider অথবা provider/model"));
    for (const [k, v] of Object.entries(d.budget[map])) {
      const num = h("input", { type: "number", value: v });
      add(box, h("div", { class: "row field" }, h("div", { class: "grow" }, k), h("div", { style: "width:7rem" }, num),
        h("button", { class: "sm pri", type: "button", on: { click: (ev) => apply(ev.target, { kind: "budget", op: "set", map, key: k, value: Number(num.value) }) } }, "সংরক্ষণ"),
        h("button", { class: "sm danger", type: "button", on: { click: (ev) => { if (confirm(`${k} সরাবেন?`)) apply(ev.target, { kind: "budget", op: "remove", map, key: k }); } } }, "✕")));
    }
    const nk = h("input", { type: "text", placeholder: "যেমন gemini" }), nv = h("input", { type: "number", placeholder: "সংখ্যা" });
    add(box, h("div", { class: "row" }, h("div", { class: "grow" }, nk), h("div", { style: "width:7rem" }, nv), h("button", { class: "sm", type: "button", on: { click: (ev) => apply(ev.target, { kind: "budget", op: "set", map, key: nk.value.trim(), value: Number(nv.value) }) } }, "যোগ")));
  }
  return h("details", null, h("summary", null, "মডেল চেইন, বাজেট ও কাজ"), box);
}

function rawSection() {
  const FILES = ["config/newsbot.yaml", "config/llm.yaml", ...["bn", "en", "ar", "de", "es", "fa", "fr", "hi", "id", "ja", "ko", "ne", "pt", "ru", "sw", "th", "tr", "ur", "vi", "zh"].map((l) => `config/sources.${l}.yaml`), "prompts/write_bn.md", "prompts/write_en.md", "prompts/write_default.md", "prompts/extract.md", "prompts/verify.md", "prompts/qa_check.md", "prompts/update.md"];
  const path = h("input", { type: "text", list: "files", placeholder: "config/… বা prompts/…" }), out = h("div");
  const dl = h("datalist", { id: "files" }, FILES.map((f) => h("option", { value: f })));
  const load = (btn) => run(btn, async () => {
    const f = await api(`/api/file?path=${encodeURIComponent(path.value.trim())}`);
    const ta = h("textarea", { value: f.text, style: "min-height:20rem;font-family:ui-monospace,monospace;font-size:.82rem" }), allow = h("input", { type: "checkbox" });
    fill(out, ta, f.path.startsWith("config/") ? h("label", { class: "check" }, allow, "কাঠামো বদলের অনুমতি (সেটিং মুছে গেলেও)") : null,
      h("div", { class: "row", style: "margin-top:.5rem" }, h("button", { class: "pri", type: "button", on: { click: (e) => run(e.target, async () => { const r = await api("/api/file", "POST", { path: f.path, text: ta.value, sha: f.sha, allowStructure: allow.checked }); toast(r.changed ? "✅ সংরক্ষিত" : "কোনো পরিবর্তন নেই"); load(btn); }) } }, "সংরক্ষণ")),
      h("h3", null, "আগের সংস্করণ"), f.history.map((c) => h("div", { class: "row field" }, h("div", { class: "grow" }, h("div", null, c.message), h("div", { class: "mut" }, ago(c.date))), h("button", { class: "sm", type: "button", on: { click: (e) => { if (confirm("এই সংস্করণ ফিরিয়ে আনবেন?")) run(e.target, async () => { await api("/api/restore", "POST", { path: f.path, ref: c.sha }); toast("✅ ফিরিয়ে আনা হয়েছে"); load(btn); }); } } }, "ফিরিয়ে আনুন"))));
  });
  return h("details", null, h("summary", null, "ফাইল (কাঁচা সম্পাদনা, প্রম্পট, ইতিহাস)"), h("div", { class: "card" }, dl, h("div", { class: "row" }, h("div", { class: "grow" }, path), h("button", { type: "button", on: { click: (e) => load(e.target) } }, "খুলুন")), out));
}

// ---------- Keys ----------
async function keysView() {
  const d = await api("/api/keys");
  clear();
  const setMap = Object.fromEntries(d.secrets.map((s) => [s.name, s.updated]));
  add(view, h("h1", null, "কী ও সিক্রেট"), h("p", { class: "mut" }, "মান কখনো দেখানো হয় না, শুধু বদলানো যায়। সংরক্ষণের আগে কী-টা সত্যিই কাজ করে কি না পরীক্ষা হয়।"));
  const form = (name, label, after) => {
    const val = h("input", { type: "password", autocomplete: "off", placeholder: "নতুন মান" }), force = h("input", { type: "checkbox" }), fwrap = h("label", { class: "check", hidden: true }, force, "পরীক্ষা ব্যর্থ, তবুও সংরক্ষণ করুন"), res = h("div", { class: "mut" });
    const wrap = h("div", { hidden: true }, val, fwrap, res, h("div", { class: "row", style: "margin-top:.4rem" },
      h("button", { class: "sm", type: "button", on: { click: (e) => run(e.target, async () => { const r = await api("/api/keys/test", "POST", { name, value: val.value }); res.textContent = (r.ok === true ? "✅ " : r.ok === false ? "❌ " : "❔ ") + r.detail; fwrap.hidden = r.ok !== false; }) } }, "পরীক্ষা"),
      h("button", { class: "sm pri", type: "button", on: { click: (e) => run(e.target, async () => {
        try { const r = await api("/api/keys/set", "POST", { name, value: val.value, force: force.checked }); val.value = ""; toast(`✅ ${name} ${r.status === "created" ? "যোগ হয়েছে" : "বদলানো হয়েছে"}`); if (r.after) fill(res, "এখন ", h("button", { class: "sm", type: "button", on: { click: (ev) => run(ev.target, async () => { await api("/api/dispatch", "POST", { workflow: r.after }); toast(`${r.after} চালু করা হয়েছে`); }) } }, `${r.after} চালান`), " যাতে Worker নতুন মান পায়।"); else route(); }
        catch (e) { res.textContent = "❌ " + e.message; fwrap.hidden = !(e.data && e.data.test && e.data.test.ok === false); throw e; } }) } }, "সংরক্ষণ")));
    return { wrap, toggle: h("button", { class: "sm", type: "button", on: { click: () => { wrap.hidden = !wrap.hidden; } } }, "বদলান") };
  };
  for (const k of d.keys) {
    const f = form(k.name, k.label, k.after);
    add(view, h("div", { class: "card" }, h("div", { class: "row sb" }, h("div", null, h("b", null, k.label), h("div", { class: "mut" }, k.name)), setMap[k.name] ? chip("সেট · " + ago(setMap[k.name]), "ok") : chip("নেই", "bad")), f.toggle, f.wrap));
  }
  const custom = d.secrets.filter((s) => !d.keys.some((k) => k.name === s.name));
  for (const s of custom) { const f = form(s.name, s.name); add(view, h("div", { class: "card" }, h("div", { class: "row sb" }, h("b", null, s.name), chip("সেট · " + ago(s.updated), "ok")), f.toggle, f.wrap)); }
  const nn = h("input", { type: "text", placeholder: "নাম, যেমন NEW_PROVIDER_API_KEY", autocapitalize: "characters" }), nv = h("input", { type: "password", autocomplete: "off", placeholder: "মান" });
  add(view, section("নতুন সিক্রেট", h("div", { class: "card" }, nn, nv, h("div", { class: "row", style: "margin-top:.4rem" }, h("button", { class: "pri sm", type: "button", on: { click: (e) => run(e.target, async () => { await api("/api/keys/set", "POST", { name: nn.value.trim(), value: nv.value }); toast("✅ যোগ হয়েছে"); route(); }) } }, "সংরক্ষণ")))));
  add(view, section("ভ্যারিয়েবল (গোপন নয়)", h("div", { class: "card" }, d.vars.map((v) => { const inp = h("input", { type: "text", value: v.value }); return h("div", { class: "field" }, h("label", null, v.name), h("div", { class: "row" }, h("div", { class: "grow" }, inp), h("button", { class: "sm pri", type: "button", on: { click: (e) => run(e.target, async () => { await api("/api/vars/set", "POST", { name: v.name, value: inp.value }); toast("✅ সংরক্ষিত"); }) } }, "সংরক্ষণ"))); }))));
}

// ---------- Runs ----------
async function runsView() {
  const d = await api("/api/runs");
  clear();
  const mode = h("select", null, [["", "মোড: সেটিং অনুযায়ী"], ["dry-run", "dry-run (কিছু লেখে না)"], ["review", "review"], ["auto", "auto"]].map(([v, t]) => h("option", { value: v }, t)));
  const go = (btn, workflow, extra = {}) => run(btn, async () => { await api("/api/dispatch", "POST", { workflow, ...extra }); toast(`${workflow} চালু করা হয়েছে`); setTimeout(route, 2500); });
  add(view, h("h1", null, "রান"), h("div", { class: "card" }, mode, h("div", { class: "row", style: "margin-top:.5rem" },
    h("button", { class: "pri sm", type: "button", on: { click: (e) => go(e.target, "hourly", { mode: mode.value }) } }, "hourly"),
    ["deploy", "validate-config", "readiness", "setup-approve"].map((w) => h("button", { class: "sm", type: "button", on: { click: (e) => go(e.target, w) } }, w)))));
  for (const r of d.runs) add(view, h("div", { class: "card" }, h("div", { class: "row sb" }, h("b", null, runIcon(r) + " " + r.name), h("span", { class: "mut" }, ago(r.created))), h("div", { class: "mut" }, `${r.event}${r.title ? " · " + r.title : ""}`), h("a", { href: r.url, target: "_blank", rel: "noopener noreferrer" }, "লগ খুলুন")));
  const dec = h("div"), more = h("details", { on: { toggle: (e) => { if (e.target.open && !dec.childElementCount) run(null, async () => { const x = await api("/api/decisions"); add(dec, ...x.items.map((i) => h("div", { class: "field" }, h("b", null, i.action || "?"), " ", h("span", { class: "mut" }, i.counts ? Object.entries(i.counts).map(([k, v]) => `${k} ${v}`).join(", ") : `${i.title || i.story_id || ""} ${i.reason || ""}`), " ", h("span", { class: "mut" }, ago(i.ts))))); }); } } }, h("summary", null, "সাম্প্রতিক সিদ্ধান্ত (কোন স্টোরি কেন বাদ/নেওয়া হলো)"), dec);
  add(view, more);
}

// ---------- More ----------
async function moreView() {
  const [prs, audit, sess] = await Promise.all([api("/api/prs"), api("/api/audit"), api("/api/session")]);
  clear();
  add(view, h("h1", null, "আরও"));
  add(view, section("খোলা PR (review মোডের আর্টিকেল)", prs.prs.length ? prs.prs.map((p) => h("div", { class: "card" }, h("b", null, `#${p.number} ${p.title}`), h("div", { class: "mut" }, ago(p.created)),
    h("div", { class: "row", style: "margin-top:.4rem" }, link("খুলুন", p.url), h("button", { class: "sm go", type: "button", on: { click: (e) => { if (confirm("merge করে প্রকাশ করবেন?")) run(e.target, async () => { await api("/api/pr", "POST", { number: p.number, action: "merge" }); toast("✅ merge হয়েছে, ডিপ্লয় চলছে"); route(); }); } } }, "merge"),
      h("button", { class: "sm danger", type: "button", on: { click: (e) => { if (confirm("PR বন্ধ করবেন?")) run(e.target, async () => { await api("/api/pr", "POST", { number: p.number, action: "close" }); toast("বন্ধ করা হয়েছে"); route(); }); } } }, "বন্ধ")))) : h("p", { class: "mut" }, "কোনো খোলা PR নেই.")));
  const sec = h("div", { class: "card" });
  const pw = h("input", { type: "password", placeholder: "পাসওয়ার্ড", autocomplete: "off" }), code = h("input", { type: "text", inputmode: "numeric", placeholder: "৬ সংখ্যার কোড", maxlength: 7 }), info = h("div");
  if (sess.totp) add(sec, chip("২-ধাপ চালু", "ok"), h("div", { class: "row", style: "margin-top:.5rem" }, pw, code, h("button", { class: "sm danger", type: "button", on: { click: (e) => run(e.target, async () => { await api("/api/totp/disable", "POST", { password: pw.value, code: code.value }); toast("২-ধাপ বন্ধ"); location.reload(); }) } }, "বন্ধ করুন")));
  else add(sec, chip("২-ধাপ বন্ধ", "bad"), h("p", { class: "mut" }, "Google Authenticator বা অনুরূপ অ্যাপে কোড বানিয়ে লগইন আরও নিরাপদ করুন।"), pw, info,
    h("div", { class: "row", style: "margin-top:.5rem" }, h("button", { class: "pri sm", type: "button", on: { click: (e) => run(e.target, async () => {
      const r = await api("/api/totp/begin", "POST", { password: pw.value });
      const c = h("input", { type: "text", inputmode: "numeric", placeholder: "অ্যাপের ৬ সংখ্যা", maxlength: 7 });
      fill(info, h("p", null, "অ্যাপে এই গোপন কী বসান (বা লিংকে চাপুন):"), h("pre", null, r.secret), h("a", { class: "btn sm", href: r.uri }, "অ্যাপে খুলুন"), c,
        h("button", { class: "sm go", type: "button", on: { click: (ev) => run(ev.target, async () => { await api("/api/totp/confirm", "POST", { code: c.value }); toast("✅ ২-ধাপ চালু"); location.reload(); }) } }, "নিশ্চিত করুন"));
    }) } }, "২-ধাপ চালু করুন")));
  add(view, section("নিরাপত্তা", sec, h("div", { class: "row" },
    h("button", { type: "button", on: { click: () => fetch("/api/logout", { method: "POST", headers: { "X-Requested-With": "newsbot" } }).then(() => location.reload()) } }, "লগআউট"),
    h("button", { class: "danger", type: "button", on: { click: (e) => { if (confirm("সব ডিভাইস থেকে লগআউট?")) run(e.target, async () => { await api("/api/logout-all", "POST", {}); location.reload(); }); } } }, "সব ডিভাইস থেকে লগআউট"))));
  add(view, section("কার্যকলাপের লগ (শেষ ১৫০)", h("div", { class: "card" }, audit.items.length ? h("table", null, audit.items.slice(0, 60).map((a) => h("tr", null, h("td", null, ago(a.t)), h("td", null, a.action), h("td", { class: "mut" }, a.detail)))) : h("p", { class: "mut" }, "কিছু নেই"))));
}

// ---------- router ----------
async function route() {
  const hash = location.hash || "#/";
  document.getElementById("nav").replaceChildren(...NAV.map(([href, icon, text]) => h("a", { href, class: (hash === href || (href !== "#/" && hash.startsWith(href.slice(0, -1)))) ? "on" : "" }, h("span", null, icon), text)));
  try {
    const m = hash.match(/^#\/(draft|article)\/([a-z]{2,3})\/(.+)$/);
    if (m) await editor(m[1], m[2], decodeURIComponent(m[3]));
    else if (hash === "#/drafts") await listView("drafts");
    else if (hash === "#/articles") await listView("articles");
    else if (hash === "#/settings") await settingsView();
    else if (hash === "#/keys") await keysView();
    else if (hash === "#/runs") await runsView();
    else if (hash === "#/more") await moreView();
    else await home();
  } catch (e) { if (e.message !== "login") { clear(); add(view, h("div", { class: "card bad" }, h("b", null, "ত্রুটি"), h("div", null, e.message), h("button", { type: "button", on: { click: () => route() } }, "আবার চেষ্টা"))); } }
}
window.addEventListener("hashchange", () => { window.scrollTo(0, 0); route(); });
document.getElementById("reload").addEventListener("click", () => route());
route();
void pct;
