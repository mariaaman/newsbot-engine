// Pure helpers (no DOM): parsing the front matter head of a draft/article and small formatters. Tested in Node.
export function parseHead(head) {
  const m = String(head).match(/^---\n([\s\S]*?)(?:\n---\n|$)/);
  const fm = m ? m[1] : "";
  const field = (k) => {
    const r = fm.match(new RegExp(`^${k}:[^\\n]*(?:\\n[ \\t]+[^\\n]*)*`, "m"));
    if (!r) return "";
    const v = r[0].slice(k.length + 1).split("\n").map((s) => s.trim()).join(" ").trim();
    if (v.startsWith('"') && v.endsWith('"')) { try { return JSON.parse(v); } catch { return v.slice(1, -1); } }
    if (v.startsWith("'") && v.endsWith("'")) return v.slice(1, -1).replace(/''/g, "'");
    return v;
  };
  const pend = fm.match(/^pending:[^\n]*\n(?:[ \t]+[^\n]*\n?)*/m);
  const reasons = pend ? [...pend[0].matchAll(/^\s*-\s+(\S+)/gm)].map((x) => x[1]) : [];
  return { title: field("title"), summary: field("summary"), date: field("date"), hidden: /^draft:\s*true\s*$/m.test(fm), reasons, gate: reasons.some((r) => !r.startsWith("sensitive:")) };
}

export function ago(iso, now = Date.now()) {
  if (!iso) return "—";
  const s = Math.max(0, Math.round((now - Date.parse(iso)) / 1000));
  if (s < 90) return `${s} সেকেন্ড আগে`;
  if (s < 5400) return `${Math.round(s / 60)} মিনিট আগে`;
  if (s < 129600) return `${Math.round(s / 3600)} ঘণ্টা আগে`;
  return `${Math.round(s / 86400)} দিন আগে`;
}

export const safeHref = (u) => (/^https?:\/\//.test(u) || u.startsWith("/") || u.startsWith("otpauth://") ? u : "#");
export const runIcon = (r) => (!r ? "·" : r.status !== "completed" ? "⏳" : r.conclusion === "success" ? "✅" : r.conclusion === "cancelled" ? "⏹" : "❌");
export const pct = (used, limit) => (limit > 0 ? Math.min(999, Math.round((used / limit) * 100)) : null);
